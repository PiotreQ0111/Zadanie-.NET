﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadanie2_programowanie_dotNET
{
    public partial class MainWindow : Window
    {
        private double _currentValue = 0;
        private double _previousValue = 0;
        private string _currentOperator = "";
        private bool _isNewEntry = true;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void NumberButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (_isNewEntry)
            {
                Display.Text = "";
                _isNewEntry = false;
            }
            Display.Text += button.Content.ToString();
        }

        private void OperatorButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            _currentOperator = button.Content.ToString();
            _previousValue = double.Parse(Display.Text);
            PreviousOperation.Text = $"{_previousValue} {_currentOperator}";
            _isNewEntry = true;
        }

        private void EqualsButton_Click(object sender, RoutedEventArgs e)
        {
            _currentValue = double.Parse(Display.Text);
            double result = 0;

            switch (_currentOperator)
            {
                case "+":
                    result = _previousValue + _currentValue;
                    break;
                case "-":
                    result = _previousValue - _currentValue;
                    break;
                case "*":
                    result = _previousValue * _currentValue;
                    break;
                case "/":
                    result = _previousValue / _currentValue;
                    break;
                case "mod":
                    result = _previousValue % _currentValue;
                    break;
                case "^":
                    result = Math.Pow(_previousValue, _currentValue);
                    break;
                case "%":
                    result = (_previousValue * _currentValue) / 100;
                    break;
            }

            Display.Text = result.ToString();
            PreviousOperation.Text = $"{_previousValue} {_currentOperator} {_currentValue} =";
            _isNewEntry = true;
        }

        private void FunctionButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            _currentValue = double.Parse(Display.Text);
            double result = 0;

            switch (button.Content.ToString())
            {
                case "sqrt":
                    result = _currentValue >= 0 ? Math.Sqrt(_currentValue) : double.NaN;
                    break;
                case "1/x":
                    result = _currentValue != 0 ? 1 / _currentValue : double.NaN;
                    break;
                case "x!":
                    result = Factorial((int)_currentValue);
                    break;
                case "log":
                    result = _currentValue > 0 ? Math.Log10(_currentValue) : double.NaN;
                    break;
                case "ln":
                    result = _currentValue > 0 ? Math.Log(_currentValue) : double.NaN;
                    break;
                case "floor":
                    result = Math.Floor(_currentValue);
                    break;
                case "ceil":
                    result = Math.Ceiling(_currentValue);
                    break;
                case "neg":
                    result = -_currentValue;
                    break;
                case "C":
                    Cancel();
                    return;
            }

            Display.Text = double.IsNaN(result) ? "Error" : result.ToString();
            PreviousOperation.Text = $"{button.Content.ToString()}({_currentValue}) =";
            _isNewEntry = true;
        }

        private double Factorial(int n)
        {
            if (n < 0)
                return double.NaN;
            if (n == 0)
                return 1;

            double result = 1;
            for (int i = 1; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }

        private void Cancel()
        {
            _previousValue = 0;
            _currentValue = 0;
            _currentOperator = "";
            Display.Text = "0";
            PreviousOperation.Text = "";
            _isNewEntry = true;
        }
    }
}
