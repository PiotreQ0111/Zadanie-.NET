﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zadanie3_programowanie_dotNET;


namespace Zadanie3_programowanie_dotNET
{
    public enum MediaFormat
    {
        VHS,
        DVD,
        BluRay,
        Cassette,
        CD,
        Pendrive
    }
}
