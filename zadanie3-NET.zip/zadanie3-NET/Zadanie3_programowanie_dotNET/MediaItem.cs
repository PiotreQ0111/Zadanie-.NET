﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie3_programowanie_dotNET
{
    [Serializable]
    public class MediaItem : INotifyPropertyChanged
    {
        private string _title;
        private string _directorOrAuthor;
        private string _studioOrPublisher;
        private string _mediaFormat;
        private DateTime _releaseDate = DateTime.Now;

        
        public string Title
        {
            get => _title;
            set
            {
                _title = value;
                OnPropertyChanged("Title");
            }
        }

        public string DirectorOrAuthor
        {
            get => _directorOrAuthor;
            set
            {
                _directorOrAuthor = value;
                OnPropertyChanged("DirectorOrAuthor");
            }
        }

        public string StudioOrPublisher
        {
            get => _studioOrPublisher;
            set
            {
                _studioOrPublisher = value;
                OnPropertyChanged("StudioOrPublisher");
            }
        }

        public string MediaFormat
        {
            get => _mediaFormat;
            set
            {
                _mediaFormat = value;
                OnPropertyChanged("MediaFormat");
            }
        }

        public DateTime ReleaseDate
        {
            get => _releaseDate;
            set
            {
                _releaseDate = value;
                OnPropertyChanged("ReleaseDate");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
