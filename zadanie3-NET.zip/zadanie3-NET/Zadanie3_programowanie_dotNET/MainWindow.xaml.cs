﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadanie3_programowanie_dotNET
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private ObservableCollection<MediaItem> _mediaCollection;
        public ObservableCollection<MediaItem> MediaCollection
        {
            get { return _mediaCollection; }
            set
            {
                _mediaCollection = value;
                OnPropertyChanged(nameof(MediaCollection));
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            MediaCollection = new ObservableCollection<MediaItem>();
            DataContext = this;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var newItem = new MediaItem();
            var editWindow = new EditWindow(newItem);
            if (editWindow.ShowDialog() == true)
            {
                MediaCollection.Add(newItem);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (MediaListBox.SelectedItem is MediaItem selectedItem)
            {
                var editWindow = new EditWindow(selectedItem);
                editWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Wybierz element do edycji.");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (MediaListBox.SelectedItem is MediaItem selectedItem)
            {
                MediaCollection.Remove(selectedItem);
            }
            else
            {
                MessageBox.Show("Wybierz element do usunięcia.");
            }
        }

        private void ImportButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    using (FileStream fs = new FileStream(openFileDialog.FileName, FileMode.Open))
                    {
                        var mediaItems = JsonSerializer.Deserialize<ObservableCollection<MediaItem>>(fs);
                        MediaCollection = mediaItems ?? new ObservableCollection<MediaItem>();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error importing file: {ex.Message}");
                }
            }
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    using (FileStream fs = new FileStream(saveFileDialog.FileName, FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, MediaCollection);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error exporting file: {ex.Message}");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
